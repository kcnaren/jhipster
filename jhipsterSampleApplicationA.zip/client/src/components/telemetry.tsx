import React, {
  ComponentClass,
  ComponentType,
  FC,
  PropsWithChildren,
  ReactElement,
  useEffect,
} from "react";
import { withAITracking } from "@microsoft/applicationinsights-react-js";
import {
  getApplicationInsights,
  reactPlugin,
} from "../services/telemetryService";
import { TelemetryProvider } from "./telemetryContext";

type TelemetryProps = PropsWithChildren<unknown>;

const Telemetry: FC<TelemetryProps> = (props: TelemetryProps): ReactElement => {
  useEffect(() => {
    getApplicationInsights();
  }, []);

  return (
    <TelemetryProvider value={reactPlugin}>{props.children}</TelemetryProvider>
  );
};

export default Telemetry;
export const withApplicationInsights = (
  component: ComponentType<unknown>,
  componentName: string,
): ComponentClass<ComponentType<unknown>, unknown> =>
  withAITracking<typeof component>(reactPlugin, component, componentName);
