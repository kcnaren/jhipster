/**
 * Application security utilities.
 */
package com.mycompany.myapp.security;
