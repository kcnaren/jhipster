import React from 'react';
import { Route } from 'react-router-dom';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import Settings from './settings/settings';
import Password from './password/password';
import Sessions from './sessions/sessions';

const AccountRoutes = () => (
  <div>
    <ErrorBoundaryRoutes>
      <Route path="settings" element={<Settings />} />
      <Route path="password" element={<Password />} />
      <Route path="sessions" element={<Sessions />} />
    </ErrorBoundaryRoutes>
  </div>
);

export default AccountRoutes;
